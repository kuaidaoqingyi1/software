#!/bin/bash
###env####
port=9001
username=admin
password=admin
configdir=/etc/supervisor
#####check env####
if [ -n "$(ss -nplt | grep $port)" ];then
  echo -e "$port port is used ...\nexit..."
  exit 1
fi

unzip -h >/dev/null 2>&1
if [ 127 = "$(echo $?)" ];then
   echo "please install unzip"
   exit 1
fi

#####install###
unzip -o setuptools-41.1.0.zip;cd setuptools-41.1.0;python setup.py install 2>&1 >/dev/null;cd ..
tar -zxf meld3-1.0.2.tar.gz;cd meld3-1.0.2;python setup.py install 2>&1 >/dev/null;cd ..
tar -zxf supervisor-4.0.4.tar.gz;cd supervisor-4.0.4;python setup.py install 2>&1 >/dev/null;cd ..

#####配置和创建服务###
if [ ! -d $configdir ];then
  mkdir -p $configdir/conf.d 
  echo_supervisord_conf > $configdir/supervisord.conf
  cat >> $configdir/supervisord.conf << EOF
[include]
files = ./conf.d/*.ini
[inet_http_server]         
port=*:$port
#username=$username 
#password=$password
EOF
fi

cat > /usr/lib/systemd/system/supervisord.service << EOF
[Unit]
Description=Supervisor daemon

[Service]
Type=forking
ExecStart=/usr/bin/supervisord -c /etc/supervisor/supervisord.conf
ExecStop=/usr/bin/supervisorctl $OPTIONS shutdown
ExecReload=/usr/bin/supervisorctl $OPTIONS reload
KillMode=process
Restart=on-failure
RestartSec=42s

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload;systemctl enable supervisord.service;systemctl restart supervisord.service
